import java.time.LocalDate;

public class Giocatore extends Atleta{
    private int numeroMaglia;
    private String ruolo;
    private String piedePreferito;
    private int goals;

    public Giocatore(){
        super();
    }

    public Giocatore(String nome, String cognome, LocalDate nascita, int altezzaCm, double peso, int numeroMaglia,String ruolo, String piedePreferito, int goals) {
        super(nome, cognome, nascita, altezzaCm, peso);
        this.numeroMaglia = numeroMaglia;
        this.ruolo = ruolo.toLowerCase();
        this.piedePreferito = piedePreferito.toLowerCase();
        this.goals = goals;
    }

    public int getNumeroMaglia() { return numeroMaglia; }
    public void setNumeroMaglia(int numeroMaglia) { this.numeroMaglia = numeroMaglia; }

    public String getRuolo() { return ruolo; }
    public void setRuolo(String ruolo) { this.ruolo = ruolo; }

    public String getPiedePreferito() { return piedePreferito; }
    public void setPiedePreferito(String piedePreferito) { this.piedePreferito = piedePreferito; }

    public int getGoals() { return goals; }
    public void setGoals(int goals) { this.goals = goals; }

    public String goal(){
        return getCognome() + " ha fatto goall!!!!!";
    }

    public String capoCannoniere(){
        return getNome() + " " + getCognome() + " con il numero " + getNumeroMaglia() + " ha fatto " + getGoals() + " goal";
    }

}

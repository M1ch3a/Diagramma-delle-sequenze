import java.time.LocalDate;

public class Atleta {

    private String nome;
    private String cognome;
    private LocalDate nascita;
    private int altezzaCm;
    private double peso;   
    
    public Atleta(){
        
    }

    public Atleta(String nome, String cognome, LocalDate nascita, int altezzaCm, double peso) {
        setNome(nome);
        setCognome(cognome);
        setNascita(nascita);
        setAltezzaCm(altezzaCm);
        setPeso(peso);
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    
    public String getCognome() { return cognome; }
    public void setCognome(String cognome) { this.cognome = cognome; }
    
    public LocalDate getNascita() { return nascita; }
    public void setNascita(LocalDate nascita) { this.nascita = nascita; }
    
    public int getAltezzaCm() { return altezzaCm; }
    public void setAltezzaCm(int altezzaCm) { this.altezzaCm = altezzaCm; }
    
    public double getPeso() { return peso; }
    public void setPeso(double peso) { this.peso = peso; }

    

}
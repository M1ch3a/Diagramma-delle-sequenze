import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        ArrayList<Giocatore> parma = new ArrayList<>(2);
        ArrayList<Giocatore> genoa = new ArrayList<>(2);

        Giocatore player = new Giocatore();

        parma.add(new Giocatore("Zion", "Suzuki", LocalDate.of(2002, 9, 21), 190, 100, 23, "portiere", "destro", 0));
        parma.add(new Giocatore("Woyo", "Coulibaly", LocalDate.of(1999, 5, 26), 185, 77, 26, "difensore", "sinistro", 0));
        parma.add(new Giocatore("Alessandro", "Circati", LocalDate.of(2003, 10, 10), 190, 78, 39, "difensore", "destro", 0));
        parma.add(new Giocatore("Adrian", "Bernabé", LocalDate.of(2001, 5, 26), 170, 68, 10, "centrocampista", "sinistro", 0));
        parma.add(new Giocatore("Dennis", "Man", LocalDate.of(1998, 9, 26), 183, 82, 98, "attaccante", "sinistro", 0));

        genoa.add(new Giocatore("Pierluigi", "Gollini", LocalDate.of(1995, 3, 18), 194, 80, 95, "portiere", "destro", 0));
        genoa.add(new Giocatore("Johan", "Vásquez", LocalDate.of(1998, 10, 22), 184, 78, 22, "difensore", "sinistro", 0));
        genoa.add(new Giocatore("Fabio", "Miretti", LocalDate.of(2003, 8, 3), 180, 75, 23, "centrocampista", "destro", 0));
        genoa.add(new Giocatore("Mario", "Balotelli", LocalDate.of(1990, 8, 12), 189, 88, 45, "attaccante", "destro", 0));
        genoa.add(new Giocatore("Andrea", "Pinamonti", LocalDate.of(1999, 5, 19), 188, 72, 19, "attaccante", "destro", 0));

        for(int i=0; i<10; i++){
            Random random = new Random();
            
            int num = random.nextInt(2);
            if(num==0){
                num = random.nextInt(5);
                switch (num) {
                    case 0:
                        player = parma.get(num);
                        player.setGoals(player.getGoals()+1);
                        System.out.println(player.goal());
                        break;
                    case 1:
                        player = parma.get(num);
                        player.setGoals(player.getGoals()+1);
                        System.out.println(player.goal());
                        break;
                    case 2:
                        player = parma.get(num);
                        player.setGoals(player.getGoals()+1);
                        System.out.println(player.goal());
                        break;
                    case 3:
                        player = parma.get(num);
                        player.setGoals(player.getGoals()+1);
                        System.out.println(player.goal());
                        break;
                    case 4:
                        player = parma.get(num);
                        player.setGoals(player.getGoals()+1);
                        System.out.println(player.goal());
                        break;
                    default:
                        break;
                }
            } else{
                num = random.nextInt(5);
                switch (num) {
                    case 0:
                        player = genoa.get(num);
                        player.setGoals(player.getGoals()+1);
                        System.out.println(player.goal());
                        break;
                    case 1:
                        player = genoa.get(num);
                        player.setGoals(player.getGoals()+1);
                        System.out.println(player.goal());
                        break;
                    case 2:
                        player = genoa.get(num);
                        player.setGoals(player.getGoals()+1);
                        System.out.println(player.goal());
                        break;
                    case 3:
                        player = genoa.get(num);
                        player.setGoals(player.getGoals()+1);
                        System.out.println(player.goal());
                        break;
                    case 4:
                        player = genoa.get(num);
                        player.setGoals(player.getGoals()+1);
                        System.out.println(player.goal());
                        break;
                    default:
                        break;
                }
            }
        }

        int parmaGoal = 0, parmaIndex=0;

        for (Giocatore giocatore : parma) {
            if(giocatore.getGoals()>parmaGoal){
                parmaGoal = giocatore.getGoals();
                parmaIndex = parma.indexOf(giocatore);
            }
        }

        int genoaGoal = 0, genoaIndex=0;

        for (Giocatore giocatore : genoa) {
            if(giocatore.getGoals()>genoaGoal){
                genoaGoal = giocatore.getGoals();
                genoaIndex = genoa.indexOf(giocatore);
            }
        }

        if(parmaGoal>genoaGoal){
            player = parma.get(parmaIndex);
            System.out.println(player.capoCannoniere() + " ed è capocannoniere della partita"); 
        } else if(parmaGoal==genoaGoal){
            player = parma.get(parmaIndex);
            System.out.println(player.capoCannoniere() + " ed è capocannoniere della sua squadra");
            player = genoa.get(genoaIndex);
            System.out.println(player.capoCannoniere() + " ed è capocannoniere della sua squadra"); 
        } else{
            player = genoa.get(genoaIndex);
            System.out.println(player.capoCannoniere() + " ed è capocannoniere della partita"); 
        }

    }
}
